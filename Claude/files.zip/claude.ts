/**
 * XJur — Integração Claude AI
 * lib/claude.ts
 *
 * Módulos cobertos:
 *  - Processos / Casos
 *  - Clientes / Partes
 *  - Documentos / Petições
 *  - Prazos / Agenda
 *  - Financeiro / Honorários
 */

import Anthropic from "@anthropic-ai/sdk";

// ---------------------------------------------------------------------------
// Tipos
// ---------------------------------------------------------------------------

export interface Processo {
  numero?: string;
  tribunal?: string;
  vara?: string;
  assunto?: string;
  parteAtiva?: string;
  partePassiva?: string;
  valorCausa?: number;
  fase?: string;
}

export interface Documento {
  tipo: string; // "petição inicial", "contestação", "recurso", etc.
  conteudo: string;
}

export interface Prazo {
  descricao: string;
  dataLimite: string; // ISO date
  processo?: string;
  tipo?: "fatal" | "ordinario";
}

export interface ClaudeResponse {
  texto: string;
  tokens: number;
}

export interface StreamCallback {
  onChunk: (chunk: string) => void;
  onDone: (totalText: string) => void;
  onError?: (error: Error) => void;
}

// ---------------------------------------------------------------------------
// Cliente singleton
// ---------------------------------------------------------------------------

function getClient(): Anthropic {
  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    throw new Error(
      "ANTHROPIC_API_KEY não definida. Configure no .env ou nas variáveis de ambiente da VPS."
    );
  }
  return new Anthropic({ apiKey });
}

const MODEL = "claude-sonnet-4-20250514";

const SYSTEM_JURIDICO = `Você é um assistente jurídico especializado no direito brasileiro.
Atua com precisão técnica, linguagem formal quando necessário e foco prático.
Sempre que citar prazos ou dispositivos legais, mencione a fonte (CPC, CLT, CC, etc.).
Responda sempre em português do Brasil.`;

// ---------------------------------------------------------------------------
// Utilitário interno
// ---------------------------------------------------------------------------

async function chamarClaude(
  mensagem: string,
  system?: string,
  maxTokens = 2048
): Promise<ClaudeResponse> {
  const client = getClient();
  const response = await client.messages.create({
    model: MODEL,
    max_tokens: maxTokens,
    system: system ?? SYSTEM_JURIDICO,
    messages: [{ role: "user", content: mensagem }],
  });

  const texto =
    response.content
      .filter((b) => b.type === "text")
      .map((b) => (b as Anthropic.TextBlock).text)
      .join("") ?? "";

  return {
    texto,
    tokens: response.usage.input_tokens + response.usage.output_tokens,
  };
}

async function streamClaude(
  mensagem: string,
  callbacks: StreamCallback,
  system?: string,
  maxTokens = 2048
): Promise<void> {
  const client = getClient();
  let fullText = "";

  try {
    const stream = client.messages.stream({
      model: MODEL,
      max_tokens: maxTokens,
      system: system ?? SYSTEM_JURIDICO,
      messages: [{ role: "user", content: mensagem }],
    });

    for await (const event of stream) {
      if (
        event.type === "content_block_delta" &&
        event.delta.type === "text_delta"
      ) {
        fullText += event.delta.text;
        callbacks.onChunk(event.delta.text);
      }
    }

    callbacks.onDone(fullText);
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    callbacks.onError?.(error);
    throw error;
  }
}

// ---------------------------------------------------------------------------
// MÓDULO 1 — Processos / Casos
// ---------------------------------------------------------------------------

/**
 * Analisa um processo e retorna resumo executivo com riscos e estratégia.
 */
export async function analisarProcesso(
  processo: Processo,
  descricaoFatos: string
): Promise<ClaudeResponse> {
  const prompt = `
Analise o seguinte processo judicial e forneça:
1. Resumo objetivo do caso
2. Principais riscos processuais e materiais
3. Pontos fortes da tese
4. Estratégia recomendada
5. Próximos passos sugeridos

DADOS DO PROCESSO:
- Número: ${processo.numero ?? "não informado"}
- Tribunal/Vara: ${processo.tribunal ?? ""} — ${processo.vara ?? ""}
- Assunto: ${processo.assunto ?? ""}
- Parte Ativa: ${processo.parteAtiva ?? ""}
- Parte Passiva: ${processo.partePassiva ?? ""}
- Valor da Causa: ${processo.valorCausa ? `R$ ${processo.valorCausa.toLocaleString("pt-BR")}` : "não informado"}
- Fase: ${processo.fase ?? ""}

DESCRIÇÃO DOS FATOS:
${descricaoFatos}
  `.trim();

  return chamarClaude(prompt, undefined, 3000);
}

/**
 * Classifica automaticamente o assunto/área do direito de um processo.
 */
export async function classificarProcesso(
  descricao: string
): Promise<ClaudeResponse> {
  const prompt = `
Classifique o processo abaixo nas seguintes dimensões:
- Área do direito (ex: Trabalhista, Civil, Tributário, Previdenciário, etc.)
- Natureza da ação
- Assunto principal (CNJ)
- Nível de complexidade (Baixo / Médio / Alto)
- Estimativa de duração provável

DESCRIÇÃO: ${descricao}

Responda em formato JSON válido com as chaves: area, natureza, assuntoCNJ, complexidade, duracaoEstimada.
  `.trim();

  return chamarClaude(prompt, undefined, 512);
}

// ---------------------------------------------------------------------------
// MÓDULO 2 — Clientes / Partes
// ---------------------------------------------------------------------------

/**
 * Gera um resumo do perfil do cliente com base nas informações fornecidas.
 */
export async function resumirCliente(
  nome: string,
  historico: string
): Promise<ClaudeResponse> {
  const prompt = `
Com base nas informações abaixo, elabore um perfil resumido do cliente para uso interno do escritório:
- Principais interesses jurídicos
- Histórico de relacionamento
- Pontos de atenção
- Oportunidades de atuação proativa

CLIENTE: ${nome}
HISTÓRICO: ${historico}
  `.trim();

  return chamarClaude(prompt);
}

// ---------------------------------------------------------------------------
// MÓDULO 3 — Documentos / Petições
// ---------------------------------------------------------------------------

/**
 * Gera minuta de petição com base nos parâmetros fornecidos.
 * Usa streaming para resposta progressiva na UI.
 */
export async function gerarMinutaPeticao(
  tipo: string,
  processo: Processo,
  instrucoes: string,
  callbacks: StreamCallback
): Promise<void> {
  const prompt = `
Elabore uma minuta de ${tipo} para o seguinte caso:

PROCESSO: ${processo.numero ?? "novo"}
PARTES: ${processo.parteAtiva ?? ""} vs ${processo.partePassiva ?? ""}
TRIBUNAL/VARA: ${processo.tribunal ?? ""} — ${processo.vara ?? ""}

INSTRUÇÕES ESPECÍFICAS:
${instrucoes}

A minuta deve seguir a estrutura formal brasileira com:
- Endereçamento correto
- Qualificação das partes
- Dos Fatos
- Do Direito (com citação de dispositivos legais e jurisprudência)
- Do Pedido
- Requerimentos finais

Use linguagem jurídica técnica e formal.
  `.trim();

  return streamClaude(prompt, callbacks, undefined, 4096);
}

/**
 * Revisa um documento jurídico e aponta melhorias.
 */
export async function revisarDocumento(
  documento: Documento
): Promise<ClaudeResponse> {
  const prompt = `
Revise o seguinte ${documento.tipo} e forneça:
1. Problemas encontrados (técnicos, formais, gramaticais)
2. Sugestões de melhoria
3. Verificação de dispositivos legais citados
4. Pontos que podem fortalecer ou enfraquecer a peça
5. Versão corrigida dos trechos problemáticos

DOCUMENTO:
${documento.conteudo}
  `.trim();

  return chamarClaude(prompt, undefined, 3000);
}

/**
 * Resume um documento longo para visualização rápida.
 */
export async function resumirDocumento(
  conteudo: string,
  tipo = "documento jurídico"
): Promise<ClaudeResponse> {
  const prompt = `
Faça um resumo executivo deste ${tipo} em até 5 pontos principais:
- Seja objetivo e direto
- Destaque datas, valores e obrigações importantes
- Identifique cláusulas de risco se houver

DOCUMENTO:
${conteudo}
  `.trim();

  return chamarClaude(prompt, undefined, 1024);
}

// ---------------------------------------------------------------------------
// MÓDULO 4 — Prazos / Agenda
// ---------------------------------------------------------------------------

/**
 * Analisa prazos críticos e gera alertas com contexto jurídico.
 */
export async function analisarPrazos(
  prazos: Prazo[]
): Promise<ClaudeResponse> {
  const listaPrazos = prazos
    .map(
      (p, i) =>
        `${i + 1}. [${p.tipo?.toUpperCase() ?? "ORDINÁRIO"}] ${p.descricao} — Vencimento: ${p.dataLimite}${p.processo ? ` (Processo: ${p.processo})` : ""}`
    )
    .join("\n");

  const prompt = `
Analise os seguintes prazos processuais e:
1. Identifique os mais críticos (ordem de prioridade)
2. Alerte sobre prazos fatais que NÃO podem ser perdidos
3. Sugira providências necessárias para cada prazo
4. Identifique possíveis conflitos de agenda

PRAZOS:
${listaPrazos}

Data de referência: ${new Date().toLocaleDateString("pt-BR")}
  `.trim();

  return chamarClaude(prompt, undefined, 2048);
}

/**
 * Calcula prazos processuais a partir de uma data base.
 */
export async function calcularPrazos(
  evento: string,
  dataBase: string,
  contexto?: string
): Promise<ClaudeResponse> {
  const prompt = `
Calcule os prazos processuais relevantes para o seguinte evento:

EVENTO: ${evento}
DATA BASE: ${dataBase}
${contexto ? `CONTEXTO ADICIONAL: ${contexto}` : ""}

Liste:
- Prazo para manifestação/resposta (com base legal)
- Prazo para recursos cabíveis
- Datas de vencimento calculadas
- Observações sobre suspensão/interrupção de prazos se aplicável

Considere o Calendário Judiciário e feriados nacionais relevantes.
  `.trim();

  return chamarClaude(prompt);
}

// ---------------------------------------------------------------------------
// MÓDULO 5 — Financeiro / Honorários
// ---------------------------------------------------------------------------

/**
 * Gera proposta de honorários com base no caso.
 */
export async function gerarPropostaHonorarios(
  processo: Processo,
  modalidade: "fixo" | "exito" | "misto",
  observacoes?: string
): Promise<ClaudeResponse> {
  const prompt = `
Com base nas informações do caso, elabore uma proposta de honorários advocatícios:

CASO: ${processo.assunto ?? "não especificado"}
PARTES: ${processo.parteAtiva ?? ""} vs ${processo.partePassiva ?? ""}
VALOR DA CAUSA: ${processo.valorCausa ? `R$ ${processo.valorCausa.toLocaleString("pt-BR")}` : "a definir"}
COMPLEXIDADE: ${processo.fase ?? "não informada"}
MODALIDADE DESEJADA: ${modalidade}
${observacoes ? `OBSERVAÇÕES: ${observacoes}` : ""}

A proposta deve incluir:
1. Justificativa dos honorários (complexidade, risco, dedicação estimada)
2. Valores sugeridos com base na tabela OAB e prática de mercado
3. Forma de pagamento recomendada
4. Cláusulas essenciais do contrato de honorários
5. Observações sobre honorários de sucumbência

Baseie-se no Estatuto da OAB e no Código de Ética da Advocacia.
  `.trim();

  return chamarClaude(prompt, undefined, 2048);
}

/**
 * Analisa viabilidade econômica de um caso.
 */
export async function analisarViabilidadeEconomica(
  processo: Processo,
  custoEstimado: number,
  descricaoRisco: string
): Promise<ClaudeResponse> {
  const prompt = `
Faça uma análise de viabilidade econômica do seguinte caso:

VALOR DA CAUSA: R$ ${processo.valorCausa?.toLocaleString("pt-BR") ?? "não informado"}
CUSTO ESTIMADO DO PROCESSO: R$ ${custoEstimado.toLocaleString("pt-BR")}
ASSUNTO: ${processo.assunto ?? ""}
DESCRIÇÃO DO RISCO: ${descricaoRisco}

Forneça:
1. Relação custo-benefício
2. Probabilidade de êxito (estimada)
3. Valor esperado ponderado pelo risco
4. Recomendação: litigar, negociar ou arquivar
5. Alternativas de resolução (mediação, acordo, etc.)
  `.trim();

  return chamarClaude(prompt);
}

// ---------------------------------------------------------------------------
// MÓDULO 6 — Chat Jurídico (uso geral)
// ---------------------------------------------------------------------------

export interface MensagemChat {
  role: "user" | "assistant";
  content: string;
}

/**
 * Chat jurídico com histórico de conversa (multi-turn).
 * Ideal para o assistente jurídico na interface do XJur.
 */
export async function chatJuridico(
  historico: MensagemChat[],
  novaMensagem: string,
  callbacks: StreamCallback,
  contextoProcesso?: Processo
): Promise<void> {
  const client = getClient();

  const systemComContexto = contextoProcesso
    ? `${SYSTEM_JURIDICO}

CONTEXTO DO PROCESSO ATIVO:
- Número: ${contextoProcesso.numero ?? "n/a"}
- Assunto: ${contextoProcesso.assunto ?? "n/a"}
- Partes: ${contextoProcesso.parteAtiva ?? ""} vs ${contextoProcesso.partePassiva ?? ""}
- Fase: ${contextoProcesso.fase ?? "n/a"}`
    : SYSTEM_JURIDICO;

  const mensagens: Anthropic.MessageParam[] = [
    ...historico.map((m) => ({ role: m.role, content: m.content })),
    { role: "user", content: novaMensagem },
  ];

  let fullText = "";

  try {
    const stream = client.messages.stream({
      model: MODEL,
      max_tokens: 2048,
      system: systemComContexto,
      messages: mensagens,
    });

    for await (const event of stream) {
      if (
        event.type === "content_block_delta" &&
        event.delta.type === "text_delta"
      ) {
        fullText += event.delta.text;
        callbacks.onChunk(event.delta.text);
      }
    }

    callbacks.onDone(fullText);
  } catch (err) {
    const error = err instanceof Error ? err : new Error(String(err));
    callbacks.onError?.(error);
    throw error;
  }
}

// ---------------------------------------------------------------------------
// Exportações agrupadas por módulo (facilita tree-shaking)
// ---------------------------------------------------------------------------

export const ClaudeProcessos = { analisarProcesso, classificarProcesso };
export const ClaudeClientes = { resumirCliente };
export const ClaudeDocumentos = { gerarMinutaPeticao, revisarDocumento, resumirDocumento };
export const ClaudePrazos = { analisarPrazos, calcularPrazos };
export const ClaudeFinanceiro = { gerarPropostaHonorarios, analisarViabilidadeEconomica };
export const ClaudeChat = { chatJuridico };
