# XJur — Integração Claude AI

## Estrutura de arquivos criados

```
src/
├── lib/
│   └── claude.ts              ← Core: todas as funções de IA
├── app/
│   └── api/
│       └── juridico/
│           ├── chat/
│           │   └── route.ts   ← Streaming SSE para o chat
│           └── [acao]/
│               └── route.ts   ← Funções síncronas (análise, revisão, etc.)
└── hooks/
    └── useClaude.ts           ← Hooks React para o frontend
```

---

## Instalação

```bash
npm install @anthropic-ai/sdk
```

---

## Configuração

```bash
cp .env.example .env.local
# Edite .env.local e insira sua ANTHROPIC_API_KEY
```

> ⚠️ A chave de API do console.anthropic.com é **separada** do plano Claude Pro/Max.  
> Crie sua chave em: https://console.anthropic.com

---

## Uso no frontend (exemplos)

### Analisar um processo

```tsx
import { useClaude } from "@/hooks/useClaude";

function PaginaProcesso({ processo }) {
  const { loading, texto, analisarProcesso } = useClaude();

  return (
    <button
      onClick={() => analisarProcesso(processo, "Descrição dos fatos...")}
      disabled={loading}
    >
      {loading ? "Analisando..." : "Analisar com IA"}
    </button>
    {texto && <div>{texto}</div>}
  );
}
```

### Chat jurídico com streaming

```tsx
import { useClaudeChat } from "@/hooks/useClaude";

function ChatJuridico({ processo }) {
  const { mensagens, streamState, enviar } = useClaudeChat(processo);

  return (
    <div>
      {mensagens.map((m, i) => (
        <div key={i} className={m.role === "user" ? "user" : "assistant"}>
          {m.content}
        </div>
      ))}
      {streamState.streaming && <div>{streamState.texto}▊</div>}
    </div>
  );
}
```

### Revisar documento

```tsx
const { revisarDocumento, loading, texto } = useClaude();

await revisarDocumento({
  tipo: "petição inicial",
  conteudo: textoDaPeticao,
});
```

---

## Funções disponíveis em `lib/claude.ts`

| Função | Módulo | Descrição |
|--------|--------|-----------|
| `analisarProcesso` | Processos | Resumo, riscos e estratégia |
| `classificarProcesso` | Processos | Área, natureza, complexidade (JSON) |
| `resumirCliente` | Clientes | Perfil e histórico do cliente |
| `gerarMinutaPeticao` | Documentos | Minuta com streaming |
| `revisarDocumento` | Documentos | Revisão técnica e formal |
| `resumirDocumento` | Documentos | Resumo executivo |
| `analisarPrazos` | Prazos | Priorização e alertas |
| `calcularPrazos` | Prazos | Cálculo com base legal |
| `gerarPropostaHonorarios` | Financeiro | Proposta com base na OAB |
| `analisarViabilidadeEconomica` | Financeiro | Custo-benefício do caso |
| `chatJuridico` | Chat | Multi-turn com contexto do processo |

---

## GitHub Actions — Configuração da chave

No repositório: **Settings → Secrets and variables → Actions**

```
ANTHROPIC_API_KEY = sk-ant-api03-...
```

No workflow:
```yaml
env:
  ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
```

---

## VPS — Configuração

```bash
# No servidor, defina a variável de ambiente
echo "ANTHROPIC_API_KEY=sk-ant-..." >> /etc/environment

# Ou no PM2 ecosystem.config.js
env: {
  ANTHROPIC_API_KEY: "sk-ant-..."
}
```
