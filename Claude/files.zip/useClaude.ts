/**
 * XJur — Hook React: useClaude
 * hooks/useClaude.ts
 *
 * Abstrai todas as chamadas à API do Claude para uso nos componentes React.
 * Gerencia loading, erro e streaming automaticamente.
 */

import { useState, useCallback, useRef } from "react";
import type { Processo, Prazo } from "@/lib/claude";

// ---------------------------------------------------------------------------
// Tipos
// ---------------------------------------------------------------------------

interface UseClaudeState {
  texto: string;
  loading: boolean;
  erro: string | null;
  tokens: number;
}

interface StreamState {
  texto: string;
  loading: boolean;
  erro: string | null;
  streaming: boolean;
}

// ---------------------------------------------------------------------------
// Hook: análises síncronas (POST → JSON)
// ---------------------------------------------------------------------------

export function useClaude() {
  const [state, setState] = useState<UseClaudeState>({
    texto: "",
    loading: false,
    erro: null,
    tokens: 0,
  });

  const chamar = useCallback(async (acao: string, payload: object) => {
    setState({ texto: "", loading: true, erro: null, tokens: 0 });

    try {
      const res = await fetch(`/api/juridico/${acao}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const err = await res.json();
        throw new Error(err.error ?? "Erro na requisição");
      }

      const data = await res.json();
      setState({ texto: data.texto, loading: false, erro: null, tokens: data.tokens });
      return data.texto as string;
    } catch (err) {
      const msg = err instanceof Error ? err.message : "Erro desconhecido";
      setState((s) => ({ ...s, loading: false, erro: msg }));
      return null;
    }
  }, []);

  // Atalhos por módulo
  const analisarProcesso = (processo: Processo, descricaoFatos: string) =>
    chamar("analisar-processo", { processo, descricaoFatos });

  const classificarProcesso = (descricao: string) =>
    chamar("classificar-processo", { descricao });

  const revisarDocumento = (documento: { tipo: string; conteudo: string }) =>
    chamar("revisar-documento", { documento });

  const resumirDocumento = (conteudo: string, tipo?: string) =>
    chamar("resumir-documento", { conteudo, tipo });

  const analisarPrazos = (prazos: Prazo[]) =>
    chamar("analisar-prazos", { prazos });

  const calcularPrazos = (evento: string, dataBase: string, contexto?: string) =>
    chamar("calcular-prazos", { evento, dataBase, contexto });

  const propostaHonorarios = (
    processo: Processo,
    modalidade: "fixo" | "exito" | "misto",
    observacoes?: string
  ) => chamar("proposta-honorarios", { processo, modalidade, observacoes });

  const viabilidadeEconomica = (
    processo: Processo,
    custoEstimado: number,
    descricaoRisco: string
  ) => chamar("viabilidade-economica", { processo, custoEstimado, descricaoRisco });

  return {
    ...state,
    analisarProcesso,
    classificarProcesso,
    revisarDocumento,
    resumirDocumento,
    analisarPrazos,
    calcularPrazos,
    propostaHonorarios,
    viabilidadeEconomica,
  };
}

// ---------------------------------------------------------------------------
// Hook: Chat jurídico com streaming SSE
// ---------------------------------------------------------------------------

export interface MensagemChat {
  role: "user" | "assistant";
  content: string;
}

export function useClaudeChat(contextoProcesso?: Processo) {
  const [mensagens, setMensagens] = useState<MensagemChat[]>([]);
  const [streamState, setStreamState] = useState<StreamState>({
    texto: "",
    loading: false,
    erro: null,
    streaming: false,
  });
  const abortRef = useRef<AbortController | null>(null);

  const enviar = useCallback(
    async (novaMensagem: string) => {
      if (streamState.loading) return;

      const novasMensagens: MensagemChat[] = [
        ...mensagens,
        { role: "user", content: novaMensagem },
      ];
      setMensagens(novasMensagens);
      setStreamState({ texto: "", loading: true, erro: null, streaming: true });

      abortRef.current = new AbortController();

      try {
        const res = await fetch("/api/juridico/chat", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          signal: abortRef.current.signal,
          body: JSON.stringify({
            mensagens: novasMensagens,
            contextoProcesso,
          }),
        });

        if (!res.ok) throw new Error("Erro na API de chat");

        const reader = res.body!.getReader();
        const decoder = new TextDecoder();
        let textoCompleto = "";

        while (true) {
          const { done, value } = await reader.read();
          if (done) break;

          const raw = decoder.decode(value);
          const lines = raw.split("\n").filter((l) => l.startsWith("data: "));

          for (const line of lines) {
            const payload = line.replace("data: ", "").trim();
            if (payload === "[DONE]") break;

            try {
              const { chunk } = JSON.parse(payload);
              textoCompleto += chunk;
              setStreamState((s) => ({
                ...s,
                texto: textoCompleto,
              }));
            } catch {
              // ignora linhas mal formadas
            }
          }
        }

        // Adiciona resposta ao histórico
        setMensagens((prev) => [
          ...prev,
          { role: "assistant", content: textoCompleto },
        ]);
        setStreamState({ texto: textoCompleto, loading: false, erro: null, streaming: false });
      } catch (err) {
        if ((err as Error).name === "AbortError") return;
        const msg = err instanceof Error ? err.message : "Erro desconhecido";
        setStreamState({ texto: "", loading: false, erro: msg, streaming: false });
      }
    },
    [mensagens, streamState.loading, contextoProcesso]
  );

  const limpar = useCallback(() => {
    setMensagens([]);
    setStreamState({ texto: "", loading: false, erro: null, streaming: false });
  }, []);

  const cancelar = useCallback(() => {
    abortRef.current?.abort();
    setStreamState((s) => ({ ...s, loading: false, streaming: false }));
  }, []);

  return {
    mensagens,
    streamState,
    enviar,
    limpar,
    cancelar,
  };
}
