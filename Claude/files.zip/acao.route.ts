/**
 * XJur — API Route: Funções Jurídicas (não-streaming)
 * app/api/juridico/[acao]/route.ts  (Next.js App Router)
 *
 * Ações disponíveis:
 *  POST /api/juridico/analisar-processo
 *  POST /api/juridico/classificar-processo
 *  POST /api/juridico/revisar-documento
 *  POST /api/juridico/resumir-documento
 *  POST /api/juridico/analisar-prazos
 *  POST /api/juridico/calcular-prazos
 *  POST /api/juridico/proposta-honorarios
 *  POST /api/juridico/viabilidade-economica
 */

import { NextRequest, NextResponse } from "next/server";
import {
  analisarProcesso,
  classificarProcesso,
  revisarDocumento,
  resumirDocumento,
  analisarPrazos,
  calcularPrazos,
  gerarPropostaHonorarios,
  analisarViabilidadeEconomica,
} from "@/lib/claude";

type Params = { params: { acao: string } };

export async function POST(req: NextRequest, { params }: Params) {
  const { acao } = params;
  const body = await req.json();

  try {
    let resultado;

    switch (acao) {
      case "analisar-processo":
        resultado = await analisarProcesso(body.processo, body.descricaoFatos);
        break;

      case "classificar-processo":
        resultado = await classificarProcesso(body.descricao);
        break;

      case "revisar-documento":
        resultado = await revisarDocumento(body.documento);
        break;

      case "resumir-documento":
        resultado = await resumirDocumento(body.conteudo, body.tipo);
        break;

      case "analisar-prazos":
        resultado = await analisarPrazos(body.prazos);
        break;

      case "calcular-prazos":
        resultado = await calcularPrazos(body.evento, body.dataBase, body.contexto);
        break;

      case "proposta-honorarios":
        resultado = await gerarPropostaHonorarios(
          body.processo,
          body.modalidade,
          body.observacoes
        );
        break;

      case "viabilidade-economica":
        resultado = await analisarViabilidadeEconomica(
          body.processo,
          body.custoEstimado,
          body.descricaoRisco
        );
        break;

      default:
        return NextResponse.json({ error: "Ação não encontrada" }, { status: 404 });
    }

    return NextResponse.json(resultado);
  } catch (err) {
    const message = err instanceof Error ? err.message : "Erro interno";
    console.error(`[XJur Claude] Erro em /${acao}:`, message);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
