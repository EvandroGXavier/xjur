/**
 * XJur — API Route: Chat Jurídico com Streaming
 * app/api/juridico/chat/route.ts  (Next.js App Router)
 */

import { NextRequest } from "next/server";
import Anthropic from "@anthropic-ai/sdk";

const MODEL = "claude-sonnet-4-20250514";

const SYSTEM_JURIDICO = `Você é um assistente jurídico especializado no direito brasileiro.
Atua com precisão técnica, linguagem formal quando necessário e foco prático.
Sempre que citar prazos ou dispositivos legais, mencione a fonte (CPC, CLT, CC, etc.).
Responda sempre em português do Brasil.`;

export async function POST(req: NextRequest) {
  const { mensagens, contextoProcesso } = await req.json();

  const client = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });

  const system = contextoProcesso
    ? `${SYSTEM_JURIDICO}\n\nCONTEXTO DO PROCESSO ATIVO:\n- Número: ${contextoProcesso.numero ?? "n/a"}\n- Assunto: ${contextoProcesso.assunto ?? "n/a"}\n- Partes: ${contextoProcesso.parteAtiva ?? ""} vs ${contextoProcesso.partePassiva ?? ""}`
    : SYSTEM_JURIDICO;

  // Streaming com ReadableStream (compatível com Next.js Edge/Node)
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    async start(controller) {
      try {
        const anthropicStream = client.messages.stream({
          model: MODEL,
          max_tokens: 2048,
          system,
          messages: mensagens,
        });

        for await (const event of anthropicStream) {
          if (
            event.type === "content_block_delta" &&
            event.delta.type === "text_delta"
          ) {
            controller.enqueue(
              encoder.encode(`data: ${JSON.stringify({ chunk: event.delta.text })}\n\n`)
            );
          }
        }

        controller.enqueue(encoder.encode("data: [DONE]\n\n"));
        controller.close();
      } catch (err) {
        controller.error(err);
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    },
  });
}
